#include <stdio.h>

int gate(int a, int b)
{
  printf("Hello from C code\n");
  return a && b;
}

