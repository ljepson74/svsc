#include "model.h"

NCSC_MODULE_EXPORT(model)

